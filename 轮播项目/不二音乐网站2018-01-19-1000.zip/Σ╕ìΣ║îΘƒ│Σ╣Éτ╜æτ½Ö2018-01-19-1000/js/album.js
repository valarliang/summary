
const Ranking=document.getElementById('Ranking')

let str = '';
let str2='';
		
//电台渲染数据
const tv = document.getElementById('tv');
// tv.onclick=function(){	
// 	broadCast();
// }

	
//排行榜渲染数据
// Ranking.onclick=function(){	
// 	rankingBand();
// }


// const boxUl = document.querySelector('.box_ul');
// const lis = boxUl.querySelectorAll('.imgBox');
// for(var i=0;i<lis.length;i++){
// const move=lis[i].querySelector('.move');
// const dicsImg = lis[i].querySelector('.dicsImg');
// const disc = lis[i].querySelector('.disc');
// 	move.onmouseover = dicsImg.onmouseover = function(){
// 			disc.style.filter = 'grayscale(0)';
// 			move.style.left= '1.2rem';
// 			move.style.transition='.5s';
		
// 	}
// 	move.onmouseout = dicsImg.onmouseout = function(){
// 			disc.style.filter = 'grayscale(1)';
// 			move.style.left = '.97rem';
// 			move.style.transition='.5s';
			
// 	}
// }



						
						
						
						
						
						
						